#include <iostream>
#include <conio.h>

int main()
{
    std::cout << "Hello World!";

    getch();
    return 0;
}

